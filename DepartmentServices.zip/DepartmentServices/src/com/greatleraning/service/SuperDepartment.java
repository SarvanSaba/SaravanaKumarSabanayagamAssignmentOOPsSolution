package com.greatleraning.service;

public class SuperDepartment {
	
	public String departmentname () {
		
		return ("Super Department");
		
	}
	
   public String getTodaysWork () {
		
		return ("No Work as of now");
		
	}

   public String getWorkDeadline () {
		
		return ("Nil");
		
	}
   
   public String isTodayAHoliday () {
	   
	   return ("Today is not a Holiday");
	   
   }
}
